licencia_nueva="Por favor comuniquese con el administrador del sistema para que con su MAC le active su licencia."
no_hay_configuracion_servidor="No hay un archivo de configuracion en el servidor."