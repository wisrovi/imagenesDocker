from django.contrib import admin
from .models import Serial, FileSincronizacion

# Register your models here.

admin.site.register(Serial)
admin.site.register(FileSincronizacion)