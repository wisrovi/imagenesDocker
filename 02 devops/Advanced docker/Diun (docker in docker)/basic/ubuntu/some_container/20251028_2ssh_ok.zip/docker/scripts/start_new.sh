#!/bin/sh

# Get replica number from IP
TASK_SLOT=$(( $(hostname -I | awk '{print $1}' | cut -d. -f4) - 1 ))
hostname wisrovi-$TASK_SLOT

# Generate containerd config
containerd config default > /etc/containerd/config.toml

# Start containerd
containerd &

# Wait for containerd to be ready
while ! ctr version >/dev/null 2>&1; do
    sleep 1
done

# Start Docker daemon
dockerd --host unix:///var/run/docker.sock --host tcp://0.0.0.0:2376 --tls=false --exec-opt native.cgroupdriver=cgroupfs &

# Wait for Docker daemon to be ready
while ! docker info >/dev/null 2>&1; do
    sleep 1
done

# Start SSH
/usr/sbin/sshd -D &

# Start Portainer
mkdir -p /data/$TASK_SLOT
portainer --bind :9000 --host unix:///var/run/docker.sock --data /data/$TASK_SLOT --templates="" --no-analytics

# Start ttyd for web terminal
ttyd -p 7681 bash &

# Wait for all processes
wait