#!/bin/bash

replica_num=$(whoami | sed 's/worker//')

if [[ $replica_num =~ ^[0-9]+$ ]] && [ $replica_num -ge 1 ]; then

  case $replica_num in
    1) IP="172.19.0.4" ;;
    2) IP="172.19.0.5" ;;
    3) IP="172.19.0.6" ;;
    *) IP="some_container-worker-$replica_num" ;;
  esac
  if [ -z "$SSH_ORIGINAL_COMMAND" ]; then
    exec ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i /etc/ssh/id_rsa -p 50422 root@$IP
  else
    exec ssh -t -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -i /etc/ssh/id_rsa -p 50422 root@$IP sh -c "$SSH_ORIGINAL_COMMAND"
  fi

else

  echo "Invalid replica: $USER"

  exit 1

fi